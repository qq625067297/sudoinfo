#!/bin/bash

# insmod dma driver 1000 
COUNT=1000
N=0

while [ $N -lt $COUNT ]

    do
    insmod yundu_dma.ko
    echo "$N insmod success"
    if [ $? -eq 0 ]
    then
    rmmod yundu_dma
        if [ $? -eq 0 ]
        then 
        echo "$N rmmod success"
        fi
    else
    echo "$N rmmod fail"
    fi
    echo "$N done"
    N=$((N+1))
    done
