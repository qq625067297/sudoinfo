#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xc8d01d53, "module_layout" },
	{ 0xde310d05, "kmalloc_caches" },
	{ 0x2caa7bd4, "pci_free_irq_vectors" },
	{ 0x537b72fe, "pcim_enable_device" },
	{ 0x77358855, "iomem_resource" },
	{ 0x42d723fb, "dma_set_mask" },
	{ 0xc3690fc, "_raw_spin_lock_bh" },
	{ 0x66cca4f9, "__x86_indirect_thunk_rcx" },
	{ 0xadd6a0f, "dma_async_tx_descriptor_init" },
	{ 0x71038ac7, "pv_ops" },
	{ 0x1e0252cf, "dma_set_coherent_mask" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x7825cc4d, "dma_async_device_register" },
	{ 0x5b8239ca, "__x86_return_thunk" },
	{ 0xaff2dd5d, "pci_set_master" },
	{ 0xf7242b1e, "pci_alloc_irq_vectors_affinity" },
	{ 0x9d2ab8ac, "__tasklet_schedule" },
	{ 0x2364c85a, "tasklet_init" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0x1ab02dc2, "_dev_err" },
	{ 0xf88dced7, "devm_kfree" },
	{ 0xea3c74e, "tasklet_kill" },
	{ 0xa76a035a, "pci_find_capability" },
	{ 0x87a21cb3, "__ubsan_handle_out_of_bounds" },
	{ 0xfdff3e35, "_dev_info" },
	{ 0x6383b27c, "__x86_indirect_thunk_rdx" },
	{ 0x32df6844, "put_device" },
	{ 0xe46021ca, "_raw_spin_unlock_bh" },
	{ 0xd0da656b, "__stack_chk_fail" },
	{ 0xb8b9f817, "kmalloc_order_trace" },
	{ 0xea066392, "__devm_request_region" },
	{ 0xead99a33, "pci_read_config_dword" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x1c937e3f, "pci_unregister_driver" },
	{ 0xaf88e69b, "kmem_cache_alloc_trace" },
	{ 0xba8fbd64, "_raw_spin_lock" },
	{ 0xe3713a3e, "__dynamic_dev_dbg" },
	{ 0xd3392ee0, "get_device" },
	{ 0x640663dd, "pci_irq_vector" },
	{ 0x37a0cba, "kfree" },
	{ 0x38882259, "pci_msi_vec_count" },
	{ 0x1b90be69, "devm_ioremap" },
	{ 0x2554c13b, "__pci_register_driver" },
	{ 0xe46f8395, "dma_async_device_unregister" },
	{ 0xc3fcadfd, "devm_kmalloc" },
	{ 0xc1514a3b, "free_irq" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("pci:v0000205Ed00001234sv*sd*bc*sc*i*");
MODULE_ALIAS("pci:v0000205Ed00005678sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "FF43BF362B018173782675E");
